declare function bootstrap(): void;
export default bootstrap;
